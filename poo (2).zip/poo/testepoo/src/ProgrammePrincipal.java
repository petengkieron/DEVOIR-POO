import java.time.LocalDate;

public class ProgrammePrincipal {
    public static void main(String[] args) {
        Boutique maBoutique = new Boutique();

        maBoutique.addProduit(new ProduitAlimentaire("Pain", "Baguette française", LocalDate.of(2024, 1, 30), 1));
        maBoutique.addProduit(new ProduitElectronique("Smartphone", "Dernier modèle haut de gamme", 24, 800));
        maBoutique.addProduit(new ProduitBoisson("Jus d'orange", "Jus d'orange bio pressé", 500, 3));

        Panier monPanier = new Panier();
        monPanier.ajouterProduit(new ProduitAlimentaire("Pain", "Baguette française", LocalDate.of(2024, 1, 30), 1));
        monPanier.ajouterProduit(new ProduitElectronique("Smartphone", "Dernier modèle haut de gamme", 24, 800));
        monPanier.ajouterProduit(new ProduitBoisson("Jus d'orange", "Jus d'orange bio pressé", 500, 3));

        System.out.println("Le prix total du panier est : " + monPanier.prixTotalPanier() + "€");
        maBoutique.afficherStock();
    }
}
